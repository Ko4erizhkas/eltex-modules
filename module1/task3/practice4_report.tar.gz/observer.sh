#!/bin/bash

CONFIG="/root/observer.conf"
LOG_FILE="/root/observer.log"

if [[ ! -f "$CONFIG" ]]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') Файл конфигурации $CONFIG не найден" >> "$LOG_FILE"
    exit 1
fi

while IFS= read -r script_path; do
    [[ -z "$script_path" ]] && continue
    SCRIPT_NAME=$(basename "$script_path")
    if ! pgrep -f "$SCRIPT_NAME" > /dev/null; then
        nohup "$script_path" &
        echo "$(date '+%Y-%m-%d %H:%M:%S') Перезапущен $SCRIPT_NAME" >> "$LOG_FILE"
    fi
done < "$CONFIG"
