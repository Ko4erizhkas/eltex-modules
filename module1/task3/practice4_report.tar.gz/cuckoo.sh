#!/bin/bash
PIPE="/tmp/run/cuckoo.pid"
LOG="/tmp/cuckoo.log"
mkdir -p /tmp/run
rm -f $PIPE
mkfifo $PIPE
echo "$(date '+%Y-%m-%d %H:%M:%S') Startup!" >> $LOG
trap 'echo "$(date "+%Y-%m-%d %H:%M:%S") Shutdown!" >> $LOG; rm -f $PIPE; exit 0' SIGTERM
while true; do
    if read -r request < $PIPE; then
        if [[ $request =~ ^([A-Za-z0-9_]+)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
            NAME="${BASH_REMATCH[1]}"
            PID="${BASH_REMATCH[2]}"
            N=$((RANDOM % 9 + 2))
            echo "$N" > $PIPE
            echo "$(date '+%Y-%m-%d %H:%M:%S') $NAME[$PID] $N" >> $LOG
        else
            echo "$(date '+%Y-%m-%d %H:%M:%S') Unknown request: $request" >> $LOG
        fi
    fi
done
