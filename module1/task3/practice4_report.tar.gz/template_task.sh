#!/bin/bash

SCRIPT_NAME=$(basename "$0")
if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

PIPE="/tmp/run/cuckoo.pid"
LOG_FILE="report_${SCRIPT_NAME%.sh}.log"

echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт запущен" >> "$LOG_FILE"

REQUEST="${SCRIPT_NAME}[$$]: how much time do I have?"
echo "$REQUEST" > "$PIPE"
read -r N < "$PIPE"

sleep "$N"

echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт завершился, работал $N секунд" >> "$LOG_FILE"
